import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FastCollinearPoints {
    private final LineSegment[] segments;

    public FastCollinearPoints(Point[] originPoints) {  // finds all line segments containing 4 or more points
        if (originPoints == null) {
            throw new IllegalArgumentException();
        }
        for (Point p : originPoints) {
            if (p == null) {
                throw new IllegalArgumentException();
            }
        }
        Point[] points = Arrays.copyOf(originPoints, originPoints.length);

        for (int i = 0; i < points.length - 1; i++) {
            for (int j = i + 1; j < points.length; j++) {
                if (points[i].compareTo(points[j]) > 0) {
                    Point tmp = points[i];
                    points[i] = points[j];
                    points[j] = tmp;
                }
            }
        }

        for (int i = 0; i < points.length - 1; i++) {
            if (points[i].compareTo(points[i + 1]) == 0) {
                throw new IllegalArgumentException();
            }
        }

        List<LineSegment> segments = new ArrayList<>();

        if (points.length >= 4){
            for (Point start : points) {
                if (start.compareTo(new Point(2, 1)) == 0) {
                    StdOut.println("");
                }
                Point[] ps = new Point[points.length];
                System.arraycopy(points, 0, ps, 0, points.length);
                Arrays.sort(ps, start.slopeOrder());
                int accumulated = 1;
                double slope = 0;
                double banSlope = -1.23456789;
                for (int i = 1; i < ps.length; i++){
                    if (accumulated == 1){
                        slope = start.slopeTo(ps[i]);
                        accumulated++;
                        if (start.compareTo(ps[i]) > 0){
                            banSlope = start.slopeTo(ps[i]);
                        }
                    } else {
                        if (start.slopeTo(ps[i]) == slope){
                            accumulated++;
                        } else {
                            if (accumulated >= 4 && slope != banSlope){
                                segments.add(new LineSegment(start, ps[i-1]));
                            }
                            accumulated = 2;
                            slope = start.slopeTo(ps[i]);
                            if (start.compareTo(ps[i]) > 0){
                                banSlope = start.slopeTo(ps[i]);
                            }
                        }
                    }
                }
                if (accumulated >= 4 && slope != banSlope){
                    segments.add(new LineSegment(start, ps[ps.length-1]));
                }
            }
        }

        this.segments = segments.toArray(new LineSegment[0]);
    }

    public int numberOfSegments() {               // the number of line segments
        return this.segments.length;
    }

    public LineSegment[] segments() {             // the line segments
        return this.segments.clone();
    }


    public static void main(String[] args) {
        // read the n points from a file
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        // print and draw the line segments
        FastCollinearPoints collinear = new FastCollinearPoints(points);
//        StdOut.println(collinear.numberOfSegments());
        for (LineSegment segment : collinear.segments()) {
//            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
    }
}